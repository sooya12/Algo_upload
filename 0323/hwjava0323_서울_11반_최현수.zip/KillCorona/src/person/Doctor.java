package person;

public class Doctor extends Person {
	private String licenseId;

	public Doctor() {}

	public Doctor(String name, int age, String phone, String hospitalId, String licenseId) {
		super(name, age, phone, hospitalId);
		this.licenseId = licenseId;
	}

	public String getLicenseId() {
		return licenseId;
	}

	public void setLicenseId(String licenseId) {
		this.licenseId = licenseId;
	}
	
	
}

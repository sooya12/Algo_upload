package person;

public class Person {
	private String name;
	private int age;
	private String phone;
	private String hospitalId;
	
	public Person() {}
	
	public Person(String name, int age, String phone, String hospitalId) {
		super();
		this.name = name;
		this.age = age;
		this.phone = phone;
		this.hospitalId = hospitalId;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getPhone() {
		return phone;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	
}

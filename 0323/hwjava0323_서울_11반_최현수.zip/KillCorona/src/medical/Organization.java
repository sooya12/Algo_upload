package medical;

public class Organization {
	private String name;			// 기관명
	private int employeeCount;		// 직원수
	
	public Organization() {}
	
	public Organization(String name, int employeeCount) {
		super();
		this.name = name;
		this.employeeCount = employeeCount;
	}

	public void about() {
		System.out.println("Organization : " + name);
	}
	
	public String getName() {
		return name;
	}

	public int getEmployeeCount() {
		return employeeCount;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmployeeCount(int employeeCount) {
		this.employeeCount = employeeCount;
	}
	
	
}

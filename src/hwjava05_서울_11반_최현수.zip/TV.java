package com.ssafy;

public class TV {
	private String number;
	private String name;
	private int price;
	private int quantity;
	private int inch;
	String displayType;
	
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	public String getDisplayType() {
		return displayType;
	}
	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}
	
	public String toString() {
		return "TV 제품 번호 : " + getNumber() 
				+ " \t 제품명 : " + getName()
				+ " \t 가격 정보 : " + getPrice()
				+ " \t 재고수량 : " + getQuantity()
				+ " \t 인치 : " + getInch()
				+ " \t 디스플레이 타입 : " + getDisplayType();
	}
}

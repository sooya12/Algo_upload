package com.ssafy;

import java.util.Scanner;

public class ProductTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("TV 또는 냉장고를 선택하세요. : ");
		String product = sc.nextLine();
		
		TV tv = new TV();
		Refrigerator ref = new Refrigerator();
		
		if(product.equals("TV")) {
			System.out.print("제품번호를 입력하세요 : ");
			tv.setNumber(sc.next());
			System.out.print("제품 이름을 입력하세요 : ");
			tv.setName(sc.next());
			System.out.print("가격을 입력하세요 : ");
			tv.setPrice(sc.nextInt());
			System.out.print("수량을 입력하세요 : ");
			tv.setQuantity(sc.nextInt());
			System.out.print("인치를 입력하세요 : ");
			tv.setInch(sc.nextInt());
			System.out.print("디스플레이 타입을 입력하세요 : ");
			tv.setDisplayType(sc.next());
			
			System.out.println(tv.toString());
		
		} else if(product.equals("냉장고")) {
			System.out.print("제품번호를 입력하세요 : ");
			ref.setNumber(sc.next());
			System.out.print("제품 이름을 입력하세요 : ");
			ref.setName(sc.next());
			System.out.print("가격을 입력하세요 : ");
			ref.setPrice(sc.nextInt());
			System.out.print("수량을 입력하세요 : ");
			ref.setQuantity(sc.nextInt());
			System.out.print("용량를 입력하세요 : ");
			ref.setCapacity(sc.nextInt());
			
			System.out.println(ref.toString());
		}
	}
}

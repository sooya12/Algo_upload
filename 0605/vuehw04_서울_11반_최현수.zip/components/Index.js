export default {
    template: `
    <div>
        <div>
            <h1>INDEX</h1>
        </div>
        <div>
            SSAFY Management Employee
        </div>
    </div>
    `,
};
// import mod from "./Regist_module.js";

export default {
    template: `
    <div>
        <h1>SSAFY HRM ADD EMPLOYEE</h1>
        <hr>
        <table>
            <tr>
                <th>아이디</th>
                <td><input type="text" id="id" ref="id" v-model="id"></td>
            </tr>
            <tr>
                <th>이름</th>
                <td><input type="text" id="name" ref="name" v-model="name"></td>
            </tr>
            <tr>
                <th>이메일</th>
                <td><input type="text" id="mailid" ref="mailid" v-model="mailid"></td>
            </tr>
            <tr>
                <th>고용일</th>
                <td><input type="date" id="start_date" ref="start_date" v-model="start_date"></td>
            </tr>
            <tr>
                <th>관리자</th>
                <td><input type="text" id="manager_id" ref="manager_id" v-model="manager_id"></td>
            </tr>
            <tr>
                <th>직책</th>
                <td>
                    <select id="title" ref="title" v-model="title">
                        <option>사장</option>
                        <option>기획부장</option>
                        <option>영업부장</option>
                        <option>총무부장</option>
                        <option>인사부장</option>
                        <option>과장</option>
                        <option>영업대표이사</option>
                        <option>사원</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th>부서</th>
                <td><input type="text" id="dept_id" ref="dept_id" v-model="dept_id"></td>
            </tr>
            <tr>
                <th>월급</th>
                <td><input type="text" id="salary" ref="salary" v-model="salary"></td>
            </tr>
            <tr>
                <th>커미션</th>
                <td><input type="text" id="commission_pct" ref="commission_pct" v-model="commission_pct"></td>
            </tr>
        </table>
        <button @click="createHandler">사원추가</button>
        <button @click="moveList">목록</button>
    </div>
    `,
    data: function(){
        return{
            id: '',
            name: '',
            mailid: '',
            start_date: '',
            manager_id: '',
            title: '',
            dept_id: '',
            salary: '',
            commission_pct: ''
        }
    },
    methods: {
        createHandler(){
            axios
            .post('http://localhost:8080/ssafy/api/employee', {
                id: this.id,
                name: this.name,
                mailid: this.mailid,
                start_date: this.start_date,
                manager_id: this.manager_id,
                title: this.itle,
                dept_id: this.dept_id,
                salary: this.salary,
                commission_pct: this.commission_pct
            })
            .then(({data}) => {
                let msg = '등록 처리 시 문제 발생';
                if(data === 'success'){
                    msg = '등록 완료';
                }
                alert(msg);
                this.moveList();
            })
            .catch(error => {
                console.log(error.response)
            });
        },
        moveList(){
            this.$router.push('/list');
        }
        // docheck(){
        //     mod.checkHandler(this.id, this.name, this.mailid, this.start_date, this.manager_id,
        //                     this.title, this.dept_id, this.salary, this.commission_pct);
        // },
        // domove(){
        //     mod.moveList();
        // }
    }
}
export default {
    template:`
    <div>
        <input type="text" v-model="searchName"><button>검색</button>
        <hr>
        <table border="1" width="700px">
            <tr>
                <th>사원 아이디</th>
                <th>사원명</th>
                <th>부서</th>
                <th>직책</th>
                <th>연봉</th>
            </tr>
            <tr v-for="(emp, index) in items" v-if="emp.name.includes(searchName)" :key="index + '_items'">
                <td><a :href="'hrm_detail.html?id=' + emp.id">{{emp.id}}</a></td>
                <td>{{emp.name}}</td>
                <td>{{emp.dept_id}}</td>
                <td>{{emp.title}}</td>
                <td>{{emp.salary}}</td>
            </tr>
        </table>
        <hr>
        <button @click="movePage">사원추가</button>
    </div>
    `,
    data: function() {
        return {
            items: [],
            searchName: ''
        };
    },
    created() {
        axios
        .get('http://localhost:8080/ssafy/api/employee/all')
        .then(({data}) => {
            this.items = data;
        });
    },
    methods: {
        movePage(){
            this.$router.push('/list');
        }, 
    },
};
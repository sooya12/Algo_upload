import Index from './components/Index.js';
import List from './components/List.js';
import Regist from './components/Regist.js';

Vue.use(VueRouter);
export default new VueRouter({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'index',
            component: Index,
        },
        {
            path: '/list',
            name: 'list',
            component: List,
        },
        {
            path: '/regist',
            name: 'regist',
            component: Regist,
        },
    ],
});
package com.ssafy.hrm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrmBootRestApplicationTests {

	@Test
	void contextLoads() {
	}

}

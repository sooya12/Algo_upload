package com.ssafy.hrm.dao;

import java.util.List;

import com.ssafy.hrm.dto.Employee;

public interface EmployeeDAO {
	
	public List<Employee> findAllEmployees() throws Exception;
	public Employee findEmployeeById(int id) throws Exception;
	public int addEmployee(Employee emp) throws Exception;
	public boolean updateEmployee(Employee emp) throws Exception;
	public boolean deleteEmployee(int id) throws Exception;
	public boolean resignEmployee(int id) throws Exception;
}

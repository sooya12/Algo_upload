<template>
    <div>
        <table>
            <tr>
                <th>아이디</th>
                <td>{{emp.id}}</td>
            </tr>
            <tr>
                <th>이름</th>
                <td>{{emp.name}}</td>
            </tr>
            <tr>
                <th>이메일</th>
                <td>{{emp.mailid}}</td>
            </tr>
            <tr>
                <th>고용일</th>
                <td>{{emp.start_date}}</td>
            </tr>
            <tr>
                <th>관리자</th>
                <td>{{emp.manager_id}}</td>
            </tr>
            <tr>
                <th>부서</th>
                <td>{{emp.dept_id}}</td>
            </tr>
            <tr>
                <th>직책</th>
                <td>{{emp.title}}</td>
            </tr>
            <tr>
                <th>부서</th>
                <td>{{emp.dept_id}}</td>
            </tr>
            <tr>
                <th>월급</th>
                <td>{{emp.salary}}</td>
            </tr>
            <tr>
                <th>커미션</th>
                <td>{{emp.commission_pct}}</td>
            </tr>
        </table>
        <button @click="changeResign">퇴사 처리</button>
        <hr>
        <button @click="movePage">사원 목록</button>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    name: 'Detail',
    data: function() {
        return {
            emp: [],
        };
    },
    created() {
        const params = new URL(document.location).searchParams;

        axios
        .get(`http://localhost:8080/ssafy/api/employee/${params.get("id")}`)
        .then(({data}) => {
            this.emp = data;
        });
    },
    methods: {
        movePage(){
            this.$router.push('/list');
        },
        changeResign(){
            axios
            .put(`http://localhost:8080/ssafy/api/employee/resign/${this.emp.id}`)
            .then(({data}) => {
                let msg = '퇴사 처리 시 문제 발생';
                if(data === 'success'){
                    msg = '퇴사 처리 완료';
                }
                alert(msg);
                this.moveList();
            })
            .catch(error => {
                console.log(error.response)
            });
        },
        moveList(){
            this.$router.push('/list');
        } 
    },
}
</script>

<style>
table {
    border: 1px #204051;
    width: 500px;
}
</style>
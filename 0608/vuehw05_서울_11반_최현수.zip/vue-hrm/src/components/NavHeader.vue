<template>
    <p>
        <router-link to="/">INDEX</router-link> | 
        <router-link to="/list">LIST</router-link> | 
        <router-link to="/regist">REGIST</router-link> |
    </p>
</template>

<script>
export default {
    name: 'NavHeader'
}
</script>

<style>

</style>
<template>
    <div>
        <div>
            <h1>INDEX</h1>
        </div>
        <div>
            SSAFY Management Employee
        </div>
    </div>
</template>

<script>
export default {
    name: 'Index'
}
</script>

<style>

</style>
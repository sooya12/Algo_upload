import Vue from "vue";
import VueRouter from "vue-router";

import Index from '@/components/Index.vue';
import List from '@/components/List.vue';
import Regist from '@/components/Regist.vue';
import Detail from '@/components/Detail.vue';

Vue.use(VueRouter);

export default new VueRouter({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'index',
            component: Index,
        },
        {
            path: '/list',
            name: 'list',
            component: List,
        },
        {
            path: '/regist',
            name: 'regist',
            component: Regist,
        },
        {
            path: '/detail',
            name: 'detail',
            component: Detail,
        }
    ],
});

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/productInput.do")
public class ProductInputServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String productname = request.getParameter("productname");
		String productprice = request.getParameter("productprice");
		String productdetail = request.getParameter("productdetail");

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("	<body>");
		out.println("<strong>상 품 명 </strong> : " + productname + " <br>" + "<strong>상품 가격</strong> : " + productprice + "원 <br> <strong>상품 상세</strong> : " + productdetail);
		out.println("	</body>");
		out.println("</html>");

	}

}

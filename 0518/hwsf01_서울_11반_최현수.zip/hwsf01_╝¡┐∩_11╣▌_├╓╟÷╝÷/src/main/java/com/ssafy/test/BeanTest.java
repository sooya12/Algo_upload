package com.ssafy.test;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

public class BeanTest {
	
	public static void main(String[] args) {
		ProductService service = new ProductServiceImpl();
		
		service.getRepo();
		
		List<Product> list = new ArrayList<Product>();
		list = service.selectAll();
		
		String id = "";
		service.select(id);
		
		Product product = new Product();
		service.insert(product);
		
		Product product2 = new Product();
		service.update(product2);
		
		String id2 = "";
		service.delete(id2);
	}
}

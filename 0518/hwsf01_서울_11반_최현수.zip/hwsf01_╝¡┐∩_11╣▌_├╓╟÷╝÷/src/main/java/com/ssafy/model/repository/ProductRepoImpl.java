package com.ssafy.model.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo {

	
	@Override
	public List<Product> selectAll() {
		System.out.println("ProductRepoImpl - selectAll()");
		List<Product> list = new ArrayList<Product>();
		
		return list;
	}

	@Override
	public Product select(String id) {
		System.out.println("ProductRepoImpl - select()");
		Product product = new Product();
		
		return product;
	}

	@Override
	public int insert(Product product) {
		System.out.println("ProductRepoImpl - insert()");
		int result = 0;
		
		return result;
	}

	@Override
	public int update(Product product) {
		System.out.println("ProductRepoImpl - update()");
		int result = 0;
		
		return result;
	}

	@Override
	public int delete(String id) {
		System.out.println("ProductRepoImpl - delete()");
		int result = 0;
		
		return result;
	}

}

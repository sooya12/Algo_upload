package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;
import com.ssafy.model.repository.ProductRepoImpl;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo repo;
	
	@Override
	public ProductRepo getRepo() {
		System.out.println("ProductServiceImpl - getRepo()");
		ProductRepo productRepo = new ProductRepoImpl();
		
		return productRepo;
	}

	@Override
	public List<Product> selectAll() {
		System.out.println("ProductServiceImpl - selectAll()");
		List<Product> list = repo.selectAll();
		
		return list;
	}

	@Override
	public Product select(String id) {
		System.out.println("ProductServiceImpl - select()");
		Product product = repo.select(id);
		
		return product;
	}

	@Override
	public int insert(Product product) {
		System.out.println("ProductServiceImpl - insert()");
		int result = repo.insert(product);
		
		return result;
	}

	@Override
	public int update(Product product) {
		System.out.println("ProductServiceImpl - update()");
		int result = repo.update(product);
		
		return result;
	}

	@Override
	public int delete(String id) {
		System.out.println("ProductServiceImpl - delete()");
		int result = repo.delete(id);
		
		return result;
	}

}

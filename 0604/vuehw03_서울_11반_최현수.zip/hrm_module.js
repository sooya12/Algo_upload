export default {
    checkHandler(id, name, deptName, title, salary){
        let err = true;
        let msg = '';
        !id && (msg = '사원 아이디 입력', err = false, $refs.id.focus());
        err && !name && (msg = '사원명 입력', err = false, $refs.name.focus());
        err && !deptName && (msg = '부서 입력', err = false, $refs.deptName.focus());
        err && !salary && (msg = '연봉 입력', err = false, $refs.salary.focus());

        if(!err) alert(msg);
        else this.createHandler(id, name, deptName, title, salary);
    },
    createHandler(id, name, deptName, title, salary){
        const emp = localStorage.getItem("emp");
        let newEmp = {
            sequence: 0,
            items: []
        };

        if(emp){
            newEmp = JSON.parse(emp);
        }

        newEmp.sequence += 1;
        newEmp.items.push({
            id: id,
            name: name,
            deptName: deptName,
            title: title,
            salary: salary
        });

        localStorage.setItem('emp', JSON.stringify(newEmp));
        alert("등록 완료");
        location.href = "./hrm_list.html";
    },
    moveList(){
        location.href = "./hrm_list.html";
    }
}
import mod from "./hrm_module.js"
import hrm_module from "./hrm_module.js";

new Vue({
    el: "#app",
    data: function(){
        return{
            id: '',
            name: '',
            deptName: '',
            title: '',
            salary: '',
        }
    },
    methods: {
        docheck(){
            mod.checkHandler(this.id, this.name, this.deptName, this.title, this.salary);
        },
        domove(){
            mod.moveList();
        }
    }
});
new Vue({
    el: "#app",
    data: {
        items: [],
        searchName: ''
    },
    created() {
        const emp = localStorage.getItem("emp");
        let newEmp = {
            sequence: 0,
            items: []
        };

        if(emp) {
            newEmp = JSON.parse(emp);
        } else {
            localStorage.setItem('emp', JSON.stringify(newEmp))
        }

        this.items = newEmp.items;
    },
    methods: {
        movePage(){
            location.href = 'hrm_regist.html';
        }, 
    }
});
package app;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import medical.Hospital;
import person.Patient;

public class NetworkHttpServerPatient {
	public static void main(String[] args) throws IOException {

		Patient p1 = new Patient("김환자", 42, "010-1111-1111", "호흡곤란", "001", true);
		Patient p2 = new Patient("나환자", 30, "010-2222-2222", "인후통", "901", false);
		Patient p3 = new Patient("이환자", 30, "010-3333-3333", "근육통", "001", true);
		Patient p4 = new Patient("최환자", 30, "010-4444-4444", "뇌출혈", "901", false);

		// 병원 Collection
		List<Patient> patientList = new ArrayList<Patient>();
		patientList.add(p1);
		patientList.add(p2);
		patientList.add(p3);
		patientList.add(p4);

		StringBuilder sb = new StringBuilder();
		sb.append("<html><body><h2>환자 정보</h2><table style='border: 1px solid green;'>");
		for (Patient p : patientList) {
			sb.append("<tr style='border: 1px solid green;'><td>").append(p.getName().charAt(0)).append("XX").append("</td><td>")
					.append(String.valueOf(p.getPhone()).substring(0, 9)).append("XXXX").append("</td></tr>");
		}
		sb.append("</table></body></html>");
		String html = sb.toString();

		try (ServerSocket ss = new ServerSocket(8090)) {
			System.out.println("[Patient Info Server is ready]");

			while (true) {
				try (Socket socket = ss.accept()) {

					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));

					bw.write("HTTP/1.1 200 OK \r\n");
					bw.write("Content-Type: text/html;charset=utf-8\r\n");
					bw.write("Content-Length: " + html.length() + "\r\n");
					bw.write("\r\n");
					bw.write(html);
					bw.write("\r\n");
					bw.flush();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

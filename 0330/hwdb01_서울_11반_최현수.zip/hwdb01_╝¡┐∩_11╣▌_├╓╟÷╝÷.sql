use scott;

select * from emp;

select * from emp where year(hiredate) = 2014;

select * from emp where ename like 'S%' or ename like '%S%' or ename like '%S';

select * from emp where comm is null;

select ename, deptno, sal, (sal*12 + sal*1.5) as "연봉" from emp where deptno = 30;

select ename, sal, (sal*0.15) as "경조비" from emp where sal >= 2000;
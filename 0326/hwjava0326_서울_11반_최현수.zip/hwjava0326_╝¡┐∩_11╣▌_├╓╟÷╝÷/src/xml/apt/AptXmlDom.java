package xml.apt;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class AptXmlDom {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("아파트명 입력 : ");
		String input = sc.next();
		
		Document docObj = null;
		try {
			String xmlFile = new File(".").getCanonicalPath()+"/src/xml/apt/AptDealHistory.xml";
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			docObj = builder.parse(xmlFile);
			
			String tagPrice = "거래금액";
			NodeList priceList = docObj.getElementsByTagName(tagPrice);
			String tagDong = "법정동";
			NodeList dongList = docObj.getElementsByTagName(tagDong);
			String tagApt = "아파트";
			NodeList aptList = docObj.getElementsByTagName(tagApt);
			
			for (int i = 0; i < aptList.getLength(); i++) {
				
				Node tmpApt = aptList.item(i).getChildNodes().item(0);
				Node tmpDong = dongList.item(i).getChildNodes().item(0);
				Node tmpPrice = priceList.item(i).getChildNodes().item(0);
				
				if (tmpApt.getNodeType() != Node.TEXT_NODE
						&& tmpApt.getNodeType() != Node.CDATA_SECTION_NODE) {
					continue;
				}
				if (tmpDong.getNodeType() != Node.TEXT_NODE
						&& tmpDong.getNodeType() != Node.CDATA_SECTION_NODE) {
					continue;
				}
				if (tmpPrice.getNodeType() != Node.TEXT_NODE
						&& tmpPrice.getNodeType() != Node.CDATA_SECTION_NODE) {
					continue;
				}
				
				String aptValue = tmpApt.getNodeValue();
				String dongValue = tmpDong.getNodeValue();
				String priceValue = tmpPrice.getNodeValue();
				
				if(aptValue.contains(input)) {
					System.out.printf(tagApt + " : %22s \t" 
							+ tagDong + " : %3s \t"
							+ tagPrice + " : %8s \t\n", aptValue,  dongValue, priceValue);
					
				}
				
			}
		} catch(ParserConfigurationException e) {
			e.printStackTrace();
		} catch(SAXException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}

	}//main

}

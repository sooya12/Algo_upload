package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import product.ProductDTO;
import product.ProductService;

@WebServlet("/productInput.do")
public class ProductInputController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int num = Integer.parseInt(request.getParameter("num"));
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String description = request.getParameter("description");
		
		ProductDTO dto = new ProductDTO();
		ProductService productService = new ProductService();
		
		dto.setNum(num);
		dto.setName(name);
		dto.setPrice(price);
		dto.setDescription(description);

		int successCnt = 0;
		
		try {
			successCnt = productService.insertProduct(dto);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		System.out.println(successCnt);
		
		Cookie cookie = null;
		
		if(successCnt == 1) {
			cookie = new Cookie("pnum", request.getParameter("num"));
			cookie.setPath("/");
			cookie.setMaxAge(60*60*24*7);
			
			response.addCookie(cookie);
			
			System.out.println(cookie.getName());
			System.out.println(cookie.getValue());
		}
		
		try {
			dto = productService.selectProduct(num);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("product", dto);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/productResult.jsp");
		dispatcher.forward(request, response);
	}

}

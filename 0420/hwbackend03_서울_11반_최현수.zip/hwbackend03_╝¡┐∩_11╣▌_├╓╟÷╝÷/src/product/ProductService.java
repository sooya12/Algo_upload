package product;

import java.sql.SQLException;
import java.util.List;

public class ProductService {
	
	public int insertProduct(ProductDTO dto) throws ClassNotFoundException, SQLException {
		ProductDAO dao = new ProductDAO();
		
		int successCnt = dao.insertProduct(dto);
		
		return successCnt;
	}
	
	public ProductDTO selectProduct(int num) throws ClassNotFoundException, SQLException {
		ProductDAO dao = new ProductDAO();
		ProductDTO dto = new ProductDTO();
		
		dto = dao.selectProduct(num);
		
		return dto;
	}
	
	public List<ProductDTO> selectAllProduct() throws ClassNotFoundException, SQLException {
		ProductDAO dao = new ProductDAO();
		ProductDTO dto = new ProductDTO();
		
		List<ProductDTO> list = dao.selectAllProduct();
		
		return list;
	}
}

package product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

	public int insertProduct(ProductDTO dto) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String user = "ssafy";
		String password = "ssafy";
		
		Connection con = DriverManager.getConnection(url, user, password);
		
		String query = "insert into product (num, name, price, description) values(?,?,?,?)";
		
		PreparedStatement psmt = con.prepareStatement(query);
		
		psmt.setInt(1, dto.getNum());
		psmt.setString(2, dto.getName());
		psmt.setString(3, dto.getPrice());
		psmt.setString(4, dto.getDescription());
		
		int successCnt = psmt.executeUpdate();
		
		psmt.close();
		con.close();
		
		return successCnt;
	}
	
	public ProductDTO selectProduct(int num) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String user = "ssafy";
		String password = "ssafy";
		
		Connection con = DriverManager.getConnection(url, user, password);
		
		String query = "select * from product where num=" + num;
		
		PreparedStatement psmt = con.prepareStatement(query);
		ResultSet rs = psmt.executeQuery();
		
		ProductDTO dto = null;
		
		while(rs.next()) {
			dto = new ProductDTO();
			dto.setNum(rs.getInt("num"));
			dto.setName(rs.getString("name"));
			dto.setPrice(rs.getString("price"));
			dto.setDescription(rs.getString("description"));
		}
		
		return dto;
	}
	
	public List<ProductDTO> selectAllProduct() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String user = "ssafy";
		String password = "ssafy";
		
		Connection con = DriverManager.getConnection(url, user, password);
		
		String query = "select * from product";
		
		PreparedStatement psmt = con.prepareStatement(query);
		ResultSet rs = psmt.executeQuery();
		
		List<ProductDTO> list = new ArrayList<ProductDTO>();
		
		while(rs.next()) {
			ProductDTO dto = new ProductDTO();
			dto.setNum(rs.getInt("num"));
			dto.setName(rs.getString("name"));
			dto.setPrice(rs.getString("price"));
			dto.setDescription(rs.getString("description"));
			
			list.add(dto);
		}
		
		
		return list;
	}
}

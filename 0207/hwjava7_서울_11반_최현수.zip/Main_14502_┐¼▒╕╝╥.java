package beakjoon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Main_14502_연구소 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int m = sc.nextInt();
		
		int[][] arr = new int[n][m];
		ArrayList<Integer> virusList = new ArrayList<>();
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				arr[i][j] = sc.nextInt();
				if(arr[i][j] == 2) {
					virusList.add(i);
					virusList.add(j);
				}
			}
		}
		
		Perm(findZero(arr), arr, virusList);
		
		System.out.println(maxZero);
		
	}
	
	static ArrayList<Integer> findZero(int[][] arr) {
		ArrayList<Integer> list = new ArrayList<>();
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				if(arr[i][j] == 0) {
					list.add(i);
					list.add(j);
				}
			}
		}
		
		return list;
	}
	
	static void Perm(ArrayList<Integer> list, int[][] arr, ArrayList<Integer> virusList) {
		int[][] wallArr = new int[3][2];
		
		for (int i = 0; i < list.size(); i+=2) {
			for (int j = i; j < list.size(); j+=2) {
				if (i == j) continue;
				for (int k = j; k < list.size(); k+=2) {
					if (i == k || j == k) continue;
					
					wallArr[0][0] = list.get(i);
					wallArr[0][1] = list.get(i+1);
					wallArr[1][0] = list.get(j);
					wallArr[1][1] = list.get(j+1);
					wallArr[2][0] = list.get(k);
					wallArr[2][1] = list.get(k+1);
					
					int[][] copyArr = new int[arr.length][arr[0].length];
					for (int l = 0; l < copyArr.length; l++) {
						System.arraycopy(arr[l], 0, copyArr[l], 0, arr[l].length);
					}
					buildWall(wallArr, copyArr, virusList);
					
				}
			}
		}
	}
	
	static void buildWall(int[][] wallArr, int[][] CopyArr, ArrayList<Integer> virusList) {
		for (int i = 0; i < wallArr.length; i++) {
			CopyArr[wallArr[i][0]][wallArr[i][1]] = 1;
		}
		
//		for (int i = 0; i < CopyArr.length; i++) {
//			
//			System.out.println(Arrays.toString(CopyArr[i]));
//		}
//		
//		System.out.println();
		
		checkVirus(CopyArr, virusList);
		
//		for (int i = 0; i < CopyArr.length; i++) {
//			
//			System.out.println(Arrays.toString(CopyArr[i]));
//		}
//		
//		System.out.println();
		
		countZero(CopyArr);
	}
	
	static void checkVirus(int[][] arr, ArrayList<Integer> virusList) {
		for (int i = 0; i < virusList.size(); i+=2) {
//			System.out.println(virusList.get(i) + " " + virusList.get(i+1));
			spreadVirus(arr, virusList.get(i), virusList.get(i+1));
			
		}
	}
	
	static int[] dy = {-1, 0, 1, 0}; // 행
	static int[] dx = {0, 1, 0, -1}; // 열
	
	static void spreadVirus(int[][] arr, int r, int c) {
		for (int i = 0; i < dy.length; i++) {
			if(r + dy[i] < 0 || r + dy[i] > arr.length-1 || c + dx[i] < 0 || c + dx[i] > arr[0].length-1) continue;
			else {
				if(arr[r+dy[i]][c+dx[i]] == 0) {
					arr[r+dy[i]][c+dx[i]] = 2;
					spreadVirus(arr, r+dy[i], c+dx[i]);
				}
			}
		}
	}
	
	static int maxZero = 0;
	
	static void countZero(int[][] arr) {
		
		int cnt = 0;
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				if(arr[i][j] == 0) cnt++;
			}
		}
		
		if(maxZero < cnt) maxZero = cnt;
	}

}

package eboard.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import cjoinmember.dto.SsafyMember2DTO;
import eboard.dto.EBoardDTO;
import eboard.service.EBoardService;
import eboard.service.EBoardServiceImpl;

@WebServlet("/EBoardController")
public class EBoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private EBoardService service;

	@Override
	public void init() throws ServletException {
		super.init();
		service = new EBoardServiceImpl();
	}

	public EBoardController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String command = request.getParameter("command");
		if(command.equals("brd_regist")) {
			PrintWriter out = response.getWriter();
			HttpSession session = request.getSession();
			SsafyMember2DTO memberDTO = (SsafyMember2DTO)session.getAttribute("user_session");
			if(memberDTO == null || memberDTO.getUserid() == null || memberDTO.getUserid().trim().equals("")) {
				out.print(-2);
				out.close();
				return;
			}
			EBoardDTO dto = new EBoardDTO();
			dto.setUserid(memberDTO.getUserid());
			dto.setSubject(request.getParameter("brd_title"));
			dto.setContent(request.getParameter("brd_cnts"));
			int successCnt = 0;
			try {
				successCnt = service.brdRegist(dto);
			} catch (Exception e) {
				successCnt = -1;
				e.printStackTrace();
			} finally {
				out.print(successCnt);
				out.close();
			}
		}//brd_regist
		else if(command.equals("brd_list")) {
			PrintWriter out = response.getWriter();
			ArrayList<EBoardDTO> list = new ArrayList<EBoardDTO>();
			JSONArray arr = new JSONArray();
			try {
				list = service.brdList();
				for(EBoardDTO dto : list) {
					JSONObject obj = new JSONObject();
					obj.put("articleno", dto.getArticleno());
					obj.put("userid", dto.getUserid());
					obj.put("subject", dto.getSubject());
					obj.put("content", dto.getContent());
					obj.put("regtime", dto.getRegtime());
					arr.add(obj);
				}
			} catch (Exception e) {
				arr = new JSONArray();
				JSONObject obj = new JSONObject();
				obj.put("message_code", "-1");
				arr.add(obj);
				e.printStackTrace();
			} finally {
				out.print(arr.toJSONString());
				out.close();
			}
		}//brd_list
		else if(command.equals("brd_detail")) {
			String articleno = request.getParameter("articleno");
			JSONArray arr = new JSONArray();
			EBoardDTO dto = null;
			try {
				dto = service.brdDetail(articleno);
				JSONObject obj = new JSONObject();
				obj.put("articleno", dto.getArticleno());
				obj.put("userid", dto.getUserid());
				obj.put("subject", dto.getSubject());
				obj.put("content", dto.getContent());
				obj.put("regtime", dto.getRegtime());
				arr.add(obj);
			} catch (Exception e) {
				arr = new JSONArray();
				JSONObject obj = new JSONObject();
				obj.put("message_code", "-1");
				arr.add(obj);
				e.printStackTrace();
			} finally {
				PrintWriter out = response.getWriter();
				out.print(arr.toJSONString());
				out.close();
			}
		}//brd_detail
		else if(command.equals("brd_modify")) {
			PrintWriter out = response.getWriter();
			HttpSession session = request.getSession();
			SsafyMember2DTO memberDTO = (SsafyMember2DTO)session.getAttribute("user_session");
			if(memberDTO == null || memberDTO.getUserid() == null || memberDTO.getUserid().trim().equals("")) {
				out.print(-2);
				out.close();
				return;
			}
			if(!memberDTO.getUserid().trim().equals(request.getParameter("mbr_id"))) {
				out.print(-3);
				out.close();
				return;
			}
			EBoardDTO dto = new EBoardDTO();
			dto.setArticleno(request.getParameter("hid_brd_no"));
			dto.setUserid(memberDTO.getUserid());
			dto.setSubject(request.getParameter("brd_title"));
			dto.setContent(request.getParameter("brd_cnts"));
			int successCnt = 0;
			try {
				successCnt = service.brdModify(dto);
			} catch (Exception e) {
				successCnt = -1;
				e.printStackTrace();
			} finally {
				out.print(successCnt);
				out.close();
			}
		}//brd_modify
		else if(command.equals("brd_delete")) {
			PrintWriter out = response.getWriter();
			HttpSession session = request.getSession();
			SsafyMember2DTO memberDTO = (SsafyMember2DTO)session.getAttribute("user_session");
			if(memberDTO == null || memberDTO.getUserid() == null || memberDTO.getUserid().trim().equals("")) {
				out.print(-2);
				out.close();
				return;
			}
			if(!memberDTO.getUserid().trim().equals(request.getParameter("mbr_id"))) {
				out.print(-3);
				out.close();
				return;
			}
			EBoardDTO dto = new EBoardDTO();
			String articleno = request.getParameter("hid_brd_no");
			int successCnt = 0;
			try {
				successCnt = service.brdDelete(articleno);
			} catch (Exception e) {
				successCnt = -1;
				e.printStackTrace();
			} finally {
				out.print(successCnt);
				out.close();
			}
		}//brd_delete
	}//process

}//class

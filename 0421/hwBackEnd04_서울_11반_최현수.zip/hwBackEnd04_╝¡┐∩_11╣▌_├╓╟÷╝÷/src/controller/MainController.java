package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.soap.Detail;

import login.LoginService;
import login.LoginServiceImpl;
import login.MemberDTO;
import product.ProductDTO;
import product.ProductService;
import product.ProductServiceImpl;

@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private LoginService loginService;
	private ProductService productService;
       
	public void init() {
		loginService = new LoginServiceImpl();
		productService = new ProductServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String act = request.getParameter("act");
		
		System.out.println(act);
		
		if("login".equals(act)) {
			login(request, response);
		} else if("logout".equals(act)) {
			logout(request, response);
		} else if("pinput".equals(act)) {
			productInput(request, response);
		} else if("plist".equals(act)) {
			productList(request, response);
		} else if("search".equals(act)) {
			searchPList(request, response);
		} else if("last".equals(act)) {
			try {
				lastProduct(request, response);
			} catch (NumberFormatException | ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		} else if("detail".equals(act)) {
			try {
				detailProduct(request, response);
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		} else if("delete".equals(act)) {
			try {
				delete(request, response);
			} catch (NumberFormatException | ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/main.jsp";
		
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		
		try {
			MemberDTO memberDTO = loginService.login(userid, userpwd);
			
			if(memberDTO != null) {
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDTO);
			} else {
				request.setAttribute("msg", "아이디 또는 비밀번호를 확인해주세요");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	private void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/main.jsp";
		
		HttpSession session = request.getSession();
		
		if(session != null) {
			session.invalidate();
		}
			
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	private void productInput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/productResult.jsp";
		
		int num = Integer.parseInt(request.getParameter("num"));
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String description = request.getParameter("description");
		
		ProductDTO dto = new ProductDTO();
		
		dto.setNum(num);
		dto.setName(name);
		dto.setPrice(price);
		dto.setDescription(description);

		int successCnt = 0;
		
		try {
			successCnt = productService.insertProduct(dto);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Cookie cookie = null;
		
		if(successCnt == 1) {
			cookie = new Cookie("pnum", request.getParameter("num"));
			cookie.setPath("/");
			cookie.setMaxAge(60*60*24*7);
			
			response.addCookie(cookie);
		}
		
		try {
			dto = productService.selectProduct(num);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("product", dto);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}
	
	private void productList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/productList.jsp";
		List<ProductDTO> list = new ArrayList<>();
		
		try {
			list = productService.selectAllProduct();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("plist", list);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}
	
	private void searchPList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path = "/productList.jsp";
		List<ProductDTO> list = new ArrayList<>();
		
		String name = request.getParameter("pname");
		String price = request.getParameter("pprice");
		
		try {
			list = productService.searchAllProduct(name, price);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("plist", list);
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	private void lastProduct(HttpServletRequest request, HttpServletResponse response) throws NumberFormatException, ClassNotFoundException, SQLException  {
		String path = "/productLast.jsp";
		
		ProductDTO dto = null;
		Cookie[] cookies = request.getCookies();
		
		dto = productService.selectProduct(Integer.parseInt(cookies[1].getValue()));
		
		request.setAttribute("product", dto);
		try {
			request.getRequestDispatcher(path).forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void detailProduct(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException  {
		String path = "/productDetail.jsp";
		
		ProductDTO dto = null;
		
		int num = Integer.parseInt(request.getParameter("num"));
		
		dto = productService.selectProduct(num);
		
		request.setAttribute("product", dto);
		try {
			request.getRequestDispatcher(path).forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void delete(HttpServletRequest request, HttpServletResponse response) throws NumberFormatException, ClassNotFoundException, SQLException {
		String path = "/productList.jsp";
		
		List<ProductDTO> list = null;
		
		int successCnt = productService.deleteProduct(Integer.parseInt(request.getParameter("num")));
		
		if(successCnt > 0) {
			list = productService.selectAllProduct();
		}
		
		request.setAttribute("plist", list);
		try {
			request.getRequestDispatcher(path).forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}		
	}
}

package login;

public interface LoginService {
	
	public MemberDTO login(String userid, String userpwd) throws Exception;
}

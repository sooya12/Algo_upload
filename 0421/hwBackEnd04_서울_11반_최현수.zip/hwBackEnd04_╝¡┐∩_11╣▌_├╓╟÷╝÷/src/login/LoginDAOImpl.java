package login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBUtil;

public class LoginDAOImpl implements LoginDAO {

	MemberDTO dto;
	
	public LoginDAOImpl() {
		dto = new MemberDTO();
	}
	
	@Override
	public MemberDTO login(String userid, String userpwd) throws SQLException {
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			String sql = "select * from user";
			
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				dto = new MemberDTO();
				
				dto.setUserid(rs.getString("userid"));
				dto.setUserpwd(rs.getString("userpwd"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			dto = null;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(psmt);
			DBUtil.close(con);
		}
		
		return dto;
	}
	
}

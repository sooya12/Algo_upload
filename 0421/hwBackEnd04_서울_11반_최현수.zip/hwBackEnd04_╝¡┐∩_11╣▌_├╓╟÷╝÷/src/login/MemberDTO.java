package login;

public class MemberDTO {
	private String userid;
	private String userpwd;

	public String getUserid() {
		return userid;
	}

	public String getUserpwd() {
		return userpwd;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}

}

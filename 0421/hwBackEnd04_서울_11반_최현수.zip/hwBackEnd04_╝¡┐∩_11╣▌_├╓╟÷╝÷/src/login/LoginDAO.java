package login;

import java.sql.SQLException;

public interface LoginDAO {
	
	public MemberDTO login(String userid, String userpwd) throws SQLException;
}

package login;

public class LoginServiceImpl implements LoginService {
	
	LoginDAO loginDAO;
	
	public LoginServiceImpl() {
		loginDAO = new LoginDAOImpl();
	}

	@Override
	public MemberDTO login(String userid, String userpwd) throws Exception {
		if(userid == null || userpwd == null) {
			throw new Exception();
		}
		
		return loginDAO.login(userid, userpwd);
	}
	
	
}

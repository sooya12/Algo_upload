package product;

import java.sql.SQLException;
import java.util.List;

public interface ProductDAO {

	public int insertProduct(ProductDTO dto) throws ClassNotFoundException, SQLException;
	
	public ProductDTO selectProduct(int num) throws ClassNotFoundException, SQLException;
	
	public List<ProductDTO> selectAllProduct() throws ClassNotFoundException, SQLException;
	
	public List<ProductDTO> searchAllProduct(String name, String price) throws ClassNotFoundException, SQLException;
	
	public int deleteProduct(int num) throws ClassNotFoundException, SQLException;
}

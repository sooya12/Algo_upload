package product;

import java.sql.SQLException;
import java.util.List;

public class ProductServiceImpl implements ProductService {
	
	ProductDAO dao;
	ProductDTO dto;
	
	public ProductServiceImpl(){
		dao = new ProductDAOImpl();
		dto = new ProductDTO();
	}
	
	public int insertProduct(ProductDTO dto) throws ClassNotFoundException, SQLException {
		int successCnt = dao.insertProduct(dto);
		
		return successCnt;
	}
	
	public ProductDTO selectProduct(int num) throws ClassNotFoundException, SQLException {
		dto = dao.selectProduct(num);
		
		return dto;
	}
	
	public List<ProductDTO> selectAllProduct() throws ClassNotFoundException, SQLException {
		List<ProductDTO> list = dao.selectAllProduct();
		
		return list;
	}
	
	public List<ProductDTO> searchAllProduct(String name, String price) throws ClassNotFoundException, SQLException {
		List<ProductDTO> list = dao.searchAllProduct(name, price);
		
		return list;
	}
	
	public int deleteProduct(int num) throws ClassNotFoundException, SQLException {
		int successCnt = dao.deleteProduct(num);
		
		return successCnt;
	}
}

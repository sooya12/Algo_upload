import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution_SWEA_9659_다항식계산_D4 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		
		int testCase = Integer.parseInt(br.readLine());
		
		for (int tc = 1; tc <= testCase; tc++) {
			int n = Integer.parseInt(br.readLine());
			
			int[][] tab = new int[n-2+1][3];
			
			if(n > 2) {
				for (int i = 0; i < tab.length; i++) {
					st = new StringTokenizer(br.readLine(), " ");
					
					tab[i][0] = Integer.parseInt(st.nextToken());
					tab[i][1] = Integer.parseInt(st.nextToken());
					tab[i][2] = Integer.parseInt(st.nextToken());
				}
			}
			
			int m = Integer.parseInt(br.readLine());
			int[] result = new int[m];
			
			st = new StringTokenizer(br.readLine(), " ");
			for (int i = 0; i < m; i++) {
				int x = Integer.parseInt(st.nextToken());
				
				long[] fn = new long[n+1];
				fn[0] = 1;
				fn[1] = x;
				
				if(n > 2) {
					for (int j = 2; j < n + 1; j++) {
						int t = tab[j - 2][0];
						int a = tab[j - 2][1];
						int b = tab[j - 2][2];
						
						switch(t) {
						case 1:
							fn[j] = (fn[a] + fn[b]) % 998244353;
							break;
							
						case 2:
							fn[j] = (a * fn[b]) % 998244353;
							break;
							
						case 3:
							fn[j] = (fn[a] * fn[b]) % 998244353;
						}
					}
					
				}
				
//				result[i] = (int) (fn[n] % 998244353);
				result[i] = (int) fn[n];
			}
			
			System.out.print("#" + tc);
			for (int i = 0; i < result.length; i++) {
				System.out.print(" " + result[i]);
			}
			System.out.println();
		}
		
	}
}

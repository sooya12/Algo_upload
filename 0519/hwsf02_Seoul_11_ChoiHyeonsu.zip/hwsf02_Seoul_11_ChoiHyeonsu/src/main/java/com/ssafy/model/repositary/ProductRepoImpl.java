package com.ssafy.model.repositary;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo {

	public List<Product> selectAll(){
		System.out.println("This is ProductRepoImpl - selectAll()");
		
		List<Product> list = new ArrayList<Product>();
		
		return list;
	}
	
	public int productRegist(Product product) {
		System.out.println("This is ProductRepoImpl - productRegist()");
		
		int successCnt = 1;
		
		return successCnt;
	}
}

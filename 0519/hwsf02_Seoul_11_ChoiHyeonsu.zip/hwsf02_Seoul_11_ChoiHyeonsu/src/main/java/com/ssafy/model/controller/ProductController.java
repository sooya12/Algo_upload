package com.ssafy.model.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService service;
	
	@RequestMapping(value = "/prdtRegPage", method = RequestMethod.GET)
	public String productRegistPage() {
		
		return "product_reg";
	}
	
	@RequestMapping(value = "/prdtReg", method = RequestMethod.GET)
	public String productRegist(Product product, Model model) {
		System.out.println(product.getName());
		
		int successCnt = service.productRegist(product);
		System.out.println(successCnt);
		
		model.addAttribute("prdt", product);
		
		return "product_reg_result";
	}
}

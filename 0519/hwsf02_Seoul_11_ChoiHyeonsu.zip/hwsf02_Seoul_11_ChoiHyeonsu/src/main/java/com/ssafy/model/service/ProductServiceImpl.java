package com.ssafy.model.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repositary.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo repo;
	
	@Override
	public List<Product> selectAll() {
		List<Product> list = new ArrayList<Product>();
		list = repo.selectAll();
		
		return list;
	}
	
	public int productRegist(Product product) {
		int successCnt = repo.productRegist(product);
		
		return successCnt;
	}

}

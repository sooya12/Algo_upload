-- 1
create table product(pcode varchar(10), pname varchar(20), price int); 


-- 2
insert into product (pcode, pname, price)
value('P01', '갤럭시 TV', 5000000),
	('P02', '갤럭시 노트북', 900000),
    ('P03', '싸피 TV 플러스', 120000),
    ('P04', '싸피 노트북', 2700000),
    ('P05', '기본 TV 세트', 950000);

select * from product;

-- 3
select pcode, pname, round(price*0.85) as 'sale price'
from product;


-- 4
update product
set price = price*0.8
where pname like '%TV%';
-- where pname like 'TV%' or pname like '%TV%' or pname like '%TV';

select * from product;


-- 5
select sum(price) as 'total price'
from product;


-- drop table product;
-- select * from product;
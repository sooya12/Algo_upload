package hwjava08_서울_11반_최현수;

public class Refrigerator extends Product {
	private int capacity;
	
	public Refrigerator(String num, String name, int price, int quantity, int capacity) {
		super(num, name, price, quantity);
		
		this.capacity = capacity;
	}

	public String toString() {
		return "냉장고 제품 번호 : " + getNumber() 
				+ " \t 제품명 : " + getName()
				+ " \t 가격 정보 : " + getPrice()
				+ " \t 재고수량 : " + getQuantity()
				+ " \t 용량 : " + getCapacity() + "L";
	}
	
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	
}

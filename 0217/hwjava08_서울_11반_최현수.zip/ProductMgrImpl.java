package hwjava08_서울_11반_최현수;

import java.util.ArrayList;

public class ProductMgrImpl implements IProductMgr {

	ArrayList<Product> list = new ArrayList<>();
	
	@Override
	public void add(Product p) {
		list.add(p);
	}

	@Override
	public void searchAll() {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
	}

	@Override
	public void searchNumber(String number) {
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getNumber().equals(number)) {
				System.out.println(list.get(i));
			}
		}
	}

	@Override
	public void searchName(String name) {
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getName().contains(name)) {
				System.out.println(list.get(i));
			}
		}		
	}

	@Override
	public void searchTV() {
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i) instanceof TV) {
				System.out.println(list.get(i));
			}
		}			
	}

	@Override
	public void searchRef() {
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i) instanceof Refrigerator) {
				System.out.println(list.get(i));
			}
		}		
	}

	@Override
	public void search400Ref() {
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i) instanceof Refrigerator && ((Refrigerator) list.get(i)).getCapacity() >= 400) {
				System.out.println(list.get(i));
			}
		}	
	}

	@Override
	public void search50TV() {
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i) instanceof TV && ((TV) list.get(i)).getInch() >= 50) {
				System.out.println(list.get(i));
			}
		}		
	}

	@Override
	public void change(String number, int price) {
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getNumber().equals(number)) {
				list.get(i).setPrice(price);
				System.out.println(list.get(i));
			}
		}
	}

	@Override
	public void delete(String number) {
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getNumber().equals(number)) {
				list.remove(list.get(i));
			}
		}
		
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
	}

	@Override
	public void totalPrice() {
		int sum = 0;
		
		for (int i = 0; i < list.size(); i++) {
			sum += list.get(i).getPrice();
		}
		
		System.out.println(sum);
	}

}

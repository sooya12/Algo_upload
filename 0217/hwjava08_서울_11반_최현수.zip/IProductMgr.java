package hwjava08_서울_11반_최현수;

public interface IProductMgr {
	
	public void add(Product p);
	
	public void searchAll();
	
	public void searchNumber(String number);
	
	public void searchName(String name);
	
	public void searchTV();
	
	public void searchRef();
	
	public void search400Ref();
	
	public void search50TV();
	
	public void change(String number, int price);
	
	public void delete(String number);
	
	public void totalPrice();
}

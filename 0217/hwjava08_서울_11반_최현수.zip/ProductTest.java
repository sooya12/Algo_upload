package hwjava08_서울_11반_최현수;


public class ProductTest {
	public static void main(String[] args) {
	
		ProductMgrImpl pmi = new ProductMgrImpl();
		
		pmi.add(new TV("1111", "삼성티비", 9000000, 100, 50, "OLED"));
		pmi.add(new TV("2222", "엘지티비", 8000000, 150, 45, "OLED"));
		pmi.add(new TV("3333", "삼성HD티비", 5000000, 800, 70, "AMOLED"));
		
		pmi.add(new Refrigerator("4444", "삼성냉장고", 800000, 450, 450));
		pmi.add(new Refrigerator("5555", "엘지냉장고", 700000, 5, 300));
		pmi.add(new Refrigerator("6666", "한성냉장고", 100000, 80, 800));
		
		System.out.println("++++++++++++ 전체 검색 ++++++++++++");
		System.out.println();
		pmi.searchAll();
		
		System.out.println();
		System.out.println("++++++++++++ 4444 검색 ++++++++++++");
		System.out.println();
		pmi.searchNumber("4444");
		
		System.out.println();
		System.out.println("++++++++++++ '티비' 들어간 제품 검색 ++++++++++++");
		System.out.println();
		pmi.searchName("티비");
		
		System.out.println();
		System.out.println("++++++++++++ TV 검색 ++++++++++++");
		System.out.println();
		pmi.searchTV();
		
		System.out.println();
		System.out.println("++++++++++++ Refrigerator 검색 ++++++++++++");
		System.out.println();
		pmi.searchRef();
		
		System.out.println();
		System.out.println("++++++++++++ 용량 400 넘는 냉장고 검색 ++++++++++++");
		System.out.println();
		pmi.search400Ref();
		
		System.out.println();
		System.out.println("++++++++++++ 50 인치 넘는 TV 검색 ++++++++++++");
		System.out.println();
		pmi.search50TV();
		
		System.out.println();
		System.out.println("++++++++++++ 품번 '1111' 가격 9로 수정 ++++++++++++");
		System.out.println();
		pmi.change("1111", 9);
		
		System.out.println();
		System.out.println("++++++++++++ 품번 '6666' 삭제 ++++++++++++");
		System.out.println();
		pmi.delete("6666");
		
		System.out.println();
		System.out.println("++++++++++++ 금액 합계 검색 ++++++++++++");
		System.out.println();
		pmi.totalPrice();
	}
}

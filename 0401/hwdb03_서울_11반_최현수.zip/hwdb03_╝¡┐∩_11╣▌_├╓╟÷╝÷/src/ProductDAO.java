import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProductDAO {
	
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	} // end of static
	
	private String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	private String user = "ssafy";
	private String pw = "ssafy";
	
	private Connection getConnection() throws SQLException {
		Connection conn = DriverManager.getConnection(url, user, pw);
		
		return conn;
	} // end of getConnection
	
	public int insertProduct(String pcode, String pname, int price) {
		int result = 0;
		
		String sql = "insert into product(pcode, pname, price) values(?, ?, ?)";
		
		PreparedStatement psmt = null;
		Connection conn = null;
		
		try {
			conn = getConnection();
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, pcode);
			psmt.setString(2, pname);
			psmt.setInt(3, price);
			
			result = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(psmt != null) psmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return result;
	} // end of insertProduct
	
	public ArrayList<Product> selectAllProduct() {
		ArrayList<Product> list = new ArrayList<>();
		
		String sql = "select * from product";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				Product p = new Product();
				
				p.setPcode(rs.getString("pcode"));
				p.setPname(rs.getString("pname"));
				p.setPrice(rs.getInt("price"));
				
				list.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(psmt != null) psmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return list;
	} // end of selectAllProduct
	
	public Product selectProduct(String pcode) {
		Product p = new Product();
		
		String sql = "select * from product where pcode = ?";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, pcode);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				p.setPcode(rs.getString("pcode"));
				p.setPname(rs.getString("pname"));
				p.setPrice(rs.getInt("price"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(psmt != null) psmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return p;
	} // end of selectProduct
	
	public int updateProduct(String pcode, int price) {
		int result = 0;
		
		String sql = "update product set price = ? where pcode = ?";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		
		try {
			conn = getConnection();
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, price);
			psmt.setString(2, pcode);
			result = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(psmt != null) psmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return result;
	} // end of updateProduct
	
	public int deleteProduct(String pcode) {
		int result = 0;
		
		String sql = "delete from product where pcode = ?";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		
		try {
			conn = getConnection();
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, pcode);
			result = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(psmt != null) psmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return result;
	} // end of deleteProduct
}

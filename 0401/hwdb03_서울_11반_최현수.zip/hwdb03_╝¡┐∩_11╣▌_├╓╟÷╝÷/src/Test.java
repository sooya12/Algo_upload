import java.util.List;

public class Test {
	public static void main(String[] args) {
		ProductDAO pdao = new ProductDAO();

//		insert
		pdao.insertProduct("P06", "갤럭시 버즈", 117000);
		pdao.insertProduct("P07", "싸피 스피커", 300000);

//		select all
		List<Product> list = pdao.selectAllProduct();

		System.out.println("전체 상품 출력");
		for (Product pro : list) {
			System.out.println(pro);
		}
		System.out.println();

//		select
		Product p = pdao.selectProduct("P04");
		System.out.println(p);
		System.out.println();

//		update
		pdao.updateProduct("P03", 800000);

		p = pdao.selectProduct("P03");
		System.out.println(p);
		System.out.println();

//		delete
		pdao.deleteProduct("P06");

		list = pdao.selectAllProduct();

		System.out.println("전체 상품 출력");
		for (Product pro : list) {
			System.out.println(pro);
		}
		System.out.println();
	}
}

<template>
    <div>
        <detail-form />
    </div>
</template>

<script>
import DetailForm from '@/components/include/Detail.vue';

export default {
    name: 'Detail',
    components: {
        DetailForm,
    },
    created() {
        this.$store.dispatch('getEmp', `/employee/${this.$route.query.id}`);
    },
};
</script>

<style>

</style>
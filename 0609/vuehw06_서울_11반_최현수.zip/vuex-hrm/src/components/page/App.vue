<template>
    <div>
        <nav-header></nav-header>
        <hr>
        <h3>SSAFY Management Employee</h3>
        <hr>
        <router-view></router-view>
    </div>
</template>

<script>
import NavHeader from '@/components/page/NavHeader.vue';    
export default {
    name: 'App',
    components: {
        NavHeader
    }
}
</script>

<style>

</style>
<template>
    <div class="container">
        <input type="text" v-model="searchName"><button>검색</button> &nbsp;
        <button @click="movePage">사원추가</button>
        <hr>
        <table border="1" width="700px">
            <tr>
                <th>사원 아이디</th>
                <th>사원명</th>
                <th>부서</th>
                <th>직책</th>
                <th>연봉</th>
                <th>퇴사 여부</th>
            </tr>
            <tr v-for="(emp, index) in emps" v-if='emp.name.includes(searchName)' :key="index + '_items'"> <!-- v-if='emp.name.includes(searchName)' -->
                <td><router-link :to="'detail?id=' + emp.id">{{emp.id}}</router-link></td>
                <td>{{emp.name}}</td>
                <td>{{emp.dept_id}}</td>
                <td>{{emp.title}}</td>
                <td>{{emp.salary}}</td>
                <td v-if="emp.resign == 0">근무</td><td v-else class="resign">퇴사</td>
            </tr>
        </table>
        <hr>
    </div>
</template>

<script>
import {mapGetters} from 'vuex';
import ListRow from '@/components/include/Row.vue';

export default {
    name: 'List',
    data: function(){
        return {
            searchName: '',
        };
    },
    components: {
        ListRow,
    },
    computed: {
        ...mapGetters(['emps']),
    },
    created() {
        this.$store.dispatch('getEmps');
    },
    methods: {
        movePage(){
            this.$router.push('/regist');
        }, 
    },
}
</script>

<style>
table {
    border: 1px #204051;
    width: 700px;
}

th {
    background-color: #204051;
    color: #ffffff;
}

tr {
    text-align: center;
}

.resign {
    background-color: #84a9ac;
}
</style>
<template>
    <div>
        <regist-form type="regist"/>
    </div>
</template>

<script>
import RegistForm from '@/components/include/Form.vue';

export default {
    name: 'regist',
    components: {
        RegistForm,
    },
};
</script>

<style>

</style>
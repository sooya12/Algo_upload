<template>
  <tr>
    <td>{{ id }}</td>
    <td>
      <router-link :to="`/detail?id=${id}`">{{ name }}</router-link>
    </td>
    <td>{{ dept_id }}</td>
    <td>{{ title }}</td>
    <td>{{ salary }}</td>
    <td>{{ resign }}</td>
  </tr>
</template>

<script>
export default {
  name: 'row',
  props: {
    id: Number,
    name: String,
    dept_id: Number,
    title: String,
    salary: String,
    resign: Number,
  },
  methods: {
    
  },
};
</script>

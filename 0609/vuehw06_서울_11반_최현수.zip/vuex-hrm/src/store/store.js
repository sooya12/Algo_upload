import Vue from 'vue';
import Vuex from 'vuex';
import http from '@/util/http-common';

Vue.use(Vuex);

export default new Vuex.Store({
    state: {
        emps: [],
        emp: {},
    },
    getters: {
        emps(state) {
            return state.emps;
        },
        emp(state) {
            return state.emp
        },
    },
    mutations: {
        setEmps(state, payload) {
            state.emps = payload;
        },
        setEmp(state, payload) {
            state.emp = payload;
        },
    },
    actions: {
        getEmps(context){
            http
            .get('/employee/all')
            .then(({data}) => {
                context.commit('setEmps', data);
            })
            .catch(() => {
                alert('에러 발생');
            });
        },
        getEmp(context, payload) {
            http
            .get(payload)
            .then(({data}) => {
                context.commit('setEmp', data);
            });
        },
    },
});
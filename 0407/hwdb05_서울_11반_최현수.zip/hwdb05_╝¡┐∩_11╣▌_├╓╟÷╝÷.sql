-- select * from emp;
-- select * from dept;

-- 1
select ename, job, sal 
from emp
where deptno = (
		select deptno from dept where loc = 'chicago');
            
-- 2
select empno, ename, job, deptno
from emp
where empno not in (
	select a.empno
    from emp as a inner join emp as b on a.empno = b.mgr);
    

-- 3
select ename, job, mgr
from emp
where mgr = (
	select mgr
    from emp
    where ename = 'blake')
    and ename != 'blake';


-- 4
select *
from emp
order by HIREDATE asc 
limit 5;


-- 5
select e.ename, e.job, d.dname
from emp e, dept d
where e.DEPTNO = d.DEPTNO 
	and e.mgr = (select empno from emp where ename='jones'); 
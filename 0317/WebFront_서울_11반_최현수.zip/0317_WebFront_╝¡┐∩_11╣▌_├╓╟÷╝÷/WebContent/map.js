/**
 * MyMap 생성자로 사용될 함수를 구현
 */

MyMap = function(){
	this.myMap = new Object();
};

MyMap.prototype.put = function(key, value){
	this.myMap[key] = value;
}

MyMap.prototype.size = function(){
	var cnt = 0;
	
	for(var m in this.myMap) cnt++;
	
	return cnt;
}

MyMap.prototype.get = function(key){
	return this.myMap[key];
}

MyMap.prototype.remove = function(key){
	delete this.myMap[key];
}

MyMap.prototype.clear = function(){
	for (var m in this.myMap) {
		delete this.myMap[m];
	}
}

package com.ssafy.model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hwsf05Seoul11ChoiHyeonsuApplicationTests {

	@Test
	void contextLoads() {
	}

}

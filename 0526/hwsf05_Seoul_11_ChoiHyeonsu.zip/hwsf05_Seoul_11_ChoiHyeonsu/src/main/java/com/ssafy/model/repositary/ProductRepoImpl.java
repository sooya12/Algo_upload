package com.ssafy.model.repositary;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo {
	
	@Autowired
	SqlSession sqlSession;

	@Override
	public List<Product> selectAll() {
		System.out.println("ProductRepoImpl - selectAll()");
		List<Product> list = sqlSession.selectList("ProductMapper.productList");
		
		return list;
	}

	@Override
	public Product select(int no) {
		System.out.println("ProductRepoImpl - select()");
		Product product = sqlSession.selectOne("ProductMapper.productSelect", no);
		
		return product;
	}

	@Override
	public int insert(Product product) {
		System.out.println("ProductRepoImpl - insert()");
		return sqlSession.insert("ProductMapper.productInsert", product);
		
	}

	@Override
	public int update(Product product) {
		System.out.println("ProductRepoImpl - update()");
		return sqlSession.update("ProductMapper.productUpdate", product);
	}

	@Override
	public int delete(int no) {
		System.out.println("ProductRepoImpl - delete()");
		return sqlSession.delete("ProductMapper.productDelete", no);
	}
}

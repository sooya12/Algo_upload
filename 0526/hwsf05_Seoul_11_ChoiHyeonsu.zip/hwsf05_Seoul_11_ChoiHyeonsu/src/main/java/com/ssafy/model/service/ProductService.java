package com.ssafy.model.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repositary.ProductRepo;

@Service
public interface ProductService {

	public ProductRepo getRepo();
	
	public List<Product> selectAll();
	
	public Product select(int no);
	
	public int insert(Product product);
	
	public int update(Product product);
	
	public int delete(int no);
}

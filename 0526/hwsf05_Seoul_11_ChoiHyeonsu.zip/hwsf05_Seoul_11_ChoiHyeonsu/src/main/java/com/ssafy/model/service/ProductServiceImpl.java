package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repositary.ProductRepo;
import com.ssafy.model.repositary.ProductRepoImpl;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo repo;
	
	@Override
	public ProductRepo getRepo() {
		System.out.println("ProductServiceImpl - getRepo()");
		ProductRepo productRepo = new ProductRepoImpl();
		
		return productRepo;
	}

	@Override
	public List<Product> selectAll() {
		System.out.println("ProductServiceImpl - selectAll()");
		List<Product> list = repo.selectAll();
		
		return list;
	}

	@Override
	public Product select(int no) {
		System.out.println("ProductServiceImpl - select()");
		Product product = repo.select(no);
		
		return product;
	}

	@Override
	public int insert(Product product) {
		System.out.println("ProductServiceImpl - insert()");
		return repo.insert(product);
	}

	@Override
	public int update(Product product) {
		System.out.println("ProductServiceImpl - update()");
		return repo.update(product);
	}

	@Override
	public int delete(int no) {
		System.out.println("ProductServiceImpl - delete()");
		return repo.delete(no);
	}

}

package com.ssafy.model;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hwsf05Seoul11ChoiHyeonsuApplication {

	public static void main(String[] args) {
		SpringApplication.run(Hwsf05Seoul11ChoiHyeonsuApplication.class, args);
	}

}

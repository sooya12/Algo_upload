package com.ssafy.model.repositary;

import java.util.List;

import com.ssafy.model.dto.Product;

public interface ProductRepo {
	
public List<Product> selectAll();
	
	public Product select(int no);
	
	public int insert(Product product);
	
	public int update(Product product);
	
	public int delete(int no);
}

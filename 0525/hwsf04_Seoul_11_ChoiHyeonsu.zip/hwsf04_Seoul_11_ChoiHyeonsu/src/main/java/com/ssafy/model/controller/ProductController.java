package com.ssafy.model.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService service;
	
	@RequestMapping(value = "/prdtInsertPage", method = RequestMethod.GET)
	public String productInsertPage() {
		
		return "product_insert";
	}
	
	@RequestMapping(value = "/prdtInsert", method = RequestMethod.POST)
	public String productRegist(Product product, Model model) {
		int successCnt = service.insert(product);
		
		model.addAttribute("prdt", product);
		
		return "product_insert_result";
	}
	
	@RequestMapping(value = "/prdtList", method = RequestMethod.GET)
	public String productList(Model model) {
		List<Product> list = service.selectAll();
		
		model.addAttribute("prdt_list", list);
		
		return "product_list";
	}
	
	@RequestMapping(value = "/form", method = RequestMethod.GET) //입력폼보기	
	public String form() {
	  return "inputForm";	
	}
	
	@RequestMapping(value = "/form", method = RequestMethod.POST) //DB입력
	public String formInsert(Product product) {
		service.insert(product);
		return "redirect:/list";	
	}
	
	@RequestMapping("/list")
	public String list(Model model) {		
		model.addAttribute("list",service.selectAll());//뷰와 공유할 데이터를 영역에 저장	
		return "list";//JSP페이지 포워딩
	}
	
	@RequestMapping(value = "/upform" , method = RequestMethod.GET)//수정폼 보이기
	public String upform(int no, Model m) {
		m.addAttribute("person",service.select(no));
		return "editForm";
	}
	
	@RequestMapping(value = "/upform" , method = RequestMethod.POST)//DB수정하기
	public String update(Product product) {
		service.update(product);		
		return "redirect:/list";
	}
	
	@RequestMapping("/delete")//DB삭제하기
	public String delete(int no) {
		service.delete(no);
		return "redirect:/list";
	}
}

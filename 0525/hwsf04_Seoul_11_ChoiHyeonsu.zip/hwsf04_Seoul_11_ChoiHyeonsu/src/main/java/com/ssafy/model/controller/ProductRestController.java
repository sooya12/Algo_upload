package com.ssafy.model.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@RestController
public class ProductRestController {

	@Autowired
	ProductService service;
	
	@GetMapping("/all")
	public List<Product> selectAll(){
		return service.selectAll();
	}
	
	@GetMapping("/{no}")
	public Product select(@PathVariable("no") int no) {
		return service.select(no);
	}
	
	@PostMapping("/")
	public String insert(Product product) {
		if(service.insert(product) == 1)
			return "success";
		else
			return "fail";
	}
	
	@PutMapping("/")
	public String update(@RequestBody Product product) {
		if(service.update(product) == 1) 
			return "success";
		else
			return "fail";
	}
	
	@DeleteMapping("/{no}")
	public String delete(@PathVariable("no") int no) {
		if(service.delete(no) == 1) 
			return "success";
		else
			return "fail";
	}
}

package product;

public class ProductDTO {
	private String name;
	private String price;
	private String description;
	
	public ProductDTO() {}
	
	public String getName() {
		return name;
	}
	public String getPrice() {
		return price;
	}
	public String getDescription() {
		return description;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}

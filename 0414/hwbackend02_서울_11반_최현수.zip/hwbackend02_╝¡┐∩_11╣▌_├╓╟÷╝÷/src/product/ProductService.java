package product;

import java.sql.SQLException;

public class ProductService {
	
	public int insertProduct(ProductDTO dto) throws ClassNotFoundException, SQLException {
		ProductDAO dao = new ProductDAO();
		
		int successCnt = dao.insertProduct(dto);
		
		return successCnt;
	}
}

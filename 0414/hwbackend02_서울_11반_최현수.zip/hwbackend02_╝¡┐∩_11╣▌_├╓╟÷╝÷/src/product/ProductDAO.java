package product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProductDAO {

	public int insertProduct(ProductDTO dto) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String user = "ssafy";
		String password = "ssafy";
		
		Connection con = DriverManager.getConnection(url, user, password);
		
		String query = "insert into product (name, price, description) values(?,?,?)";
		
		PreparedStatement psmt = con.prepareStatement(query);
		
		psmt.setString(1, dto.getName());
		psmt.setString(2, dto.getPrice());
		psmt.setString(3, dto.getDescription());
		
		int successCnt = psmt.executeUpdate();
		
		psmt.close();
		con.close();
		
		return successCnt;
	}
}

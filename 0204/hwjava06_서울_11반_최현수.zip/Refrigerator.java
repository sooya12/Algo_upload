package hwjava06_서울_11반_최현수;

public class Refrigerator extends Product {
	private int capacity;
	
	public Refrigerator(String num, String name, int price, int quantity, int capacity) {
		super(num, name, price, quantity);
		
		this.capacity = capacity;
	}

	public String toString() {
		return "냉장고 제품 번호 : " + getNumber() 
				+ " \t 제품명 : " + getName()
				+ " \t 가격 정보 : " + getPrice()
				+ " \t 재고수량 : " + getQuantity()
				+ " \t 용량 : " + getCapacity() + "L";
	}
	
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	
}

package hwjava06_서울_11반_최현수;

public class Product {
	protected String number;
	protected String name;
	protected int price;
	protected int quantity;
	
	public Product(String num, String name, int price, int quantity) {
		this.number = num;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}

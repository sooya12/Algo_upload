package hwjava06_서울_11반_최현수;


public class ProductMgr {
	
	Product[] pArr = new Product[10];
	int idx = 0;
	
	public void inputTV(String num, String name, int price, int quantity, int inch, String display) {
		pArr[idx] = new TV(num, name, price, quantity, inch, display);
		idx++;
	}
	
	public void inputRef(String num, String name, int price, int quantity, int capacity) {
		pArr[idx] = new Refrigerator(num, name, price, quantity, capacity);
		idx++;
	}
	
	
	public void searchAll() {
		for (int i = 0; i < idx; i++) {
			System.out.println(pArr[i].toString());
		}
	}
	
	public void searchNum(String snum) {
		for (int i = 0; i < idx; i++) {
			if(pArr[i].getNumber().equals(snum)) System.out.println(pArr[i].toString());
		}
	}
	
	public void searchName(String sname) {
		for (int i = 0; i < idx; i++) {
			if(pArr[i].getName().equals(sname)) System.out.println(pArr[i].toString());
		}
	}
	
	public void searchTV() {
		for (int i = 0; i < idx; i++) {
			if(pArr[i] instanceof TV) System.out.println(pArr[i].toString());
		}
	}
	
	public void searchRef() {
		for (int i = 0; i < idx; i++) {
			if(pArr[i] instanceof Refrigerator) System.out.println(pArr[i].toString());
		}
	}
	
	public void delete(String sidx) {
		int tmpIdx = 0;
		
		for (int i = 0; i < idx; i++) {
			if(pArr[i].getNumber().equals(sidx)) tmpIdx = i;
		}
		
		for (int i = tmpIdx; i < idx; i++) {
			pArr[i] = pArr[i+1];
		}
		
		--idx;
		System.out.println("======================== 남은 상품 목록 ========================");
		for (int i = 0; i < idx; i++) {
			System.out.println(pArr[i].toString());
		}
	}
	
	public void allPrice() {
		int sum = 0;
		
		for (int i = 0; i < idx; i++) {
			sum += pArr[i].getPrice();
		}
		
		System.out.println(sum);
	}
}

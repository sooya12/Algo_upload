package hwjava06_서울_11반_최현수;

import java.util.Scanner;

public class ProductTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ProductMgr pmgr = new ProductMgr();
		
		boolean turn = true;
		
		while(turn) {
			System.out.println("1. 상품 저장");
			System.out.println("2. 상품 전체 검색");
			System.out.println("3. 상품번호 검색");
			System.out.println("4. 상품명 검색");
			System.out.println("5. TV 정보 검색");
			System.out.println("6. Refrigerator 정보 검색");
			System.out.println("7. 상품번호 상품 삭제");
			System.out.println("8. 전체 재고 상품 금액");
			System.out.println("0000 입력 시, 종료");
			System.out.println();
			
			int n = sc.nextInt();
			
			switch(n) {
			
			case 1:
				System.out.print("1. TV    2. Refrigerator 선택");
				
				int select = sc.nextInt();
				
				if(select == 1) {
					System.out.print("제품번호 입력 : ");
					String num = sc.next();
					System.out.print("제품명 입력 : ");
					String name = sc.next();
					System.out.print("제품가격 입력 : ");
					int price = sc.nextInt();
					System.out.print("제품 수량 입력 : ");
					int quantity = sc.nextInt();
					System.out.print("제품 인치 입력 : ");
					int inch = sc.nextInt();
					System.out.print("제품 디스플레이 타입 입력 : ");
					String display = sc.next();
					
					pmgr.inputTV(num, name, price, quantity, inch, display);
					
				} else if(select == 2) {
					System.out.print("제품번호 입력 : ");
					String num = sc.next();
					System.out.print("제품명 입력 : ");
					String name = sc.next();
					System.out.print("제품가격 입력 : ");
					int price = sc.nextInt();
					System.out.print("제품 수량 입력 : ");
					int quantity = sc.nextInt();
					System.out.print("제품 용량 입력 : ");
					int capacity = sc.nextInt();
					
					pmgr.inputRef(num, name, price, quantity, capacity);
				}
				break;
				
			case 2:
				pmgr.searchAll();
				break;
				
			case 3:
				System.out.print("상품 번호 입력 : ");
				String snum = sc.next();
				pmgr.searchNum(snum);
				break;
				
			case 4:
				System.out.print("상품명 입력 : ");
				String sname = sc.next();
				pmgr.searchName(sname);
				break;
				
			case 5:
				pmgr.searchTV();
				break;
				
			case 6:
				pmgr.searchRef();
				break;
				
			case 7:
				System.out.print("상품 번호 입력 : ");
				String sidx = sc.next();
				pmgr.delete(sidx);
				break;
				
			case 8:
				pmgr.allPrice();
				break;
				
			case 0000:
				turn = false;
				break;
			}
		}
	}
	
	
	
}

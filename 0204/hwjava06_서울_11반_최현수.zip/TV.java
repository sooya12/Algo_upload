package hwjava06_서울_11반_최현수;

public class TV extends Product {
	private int inch;
	String displayType;
	
	public TV(String num, String name, int price, int quantity, int inch, String display) {
		super(num, name, price, quantity);
		
		this.inch = inch;
		this.displayType = display;
	}

	public String toString() {
		return "TV 제품 번호 : " + getNumber() 
				+ " \t 제품명 : " + getName()
				+ " \t 가격 정보 : " + getPrice()
				+ " \t 재고수량 : " + getQuantity()
				+ " \t 인치 : " + getInch()
				+ " \t 디스플레이 타입 : " + getDisplayType();
	}
	
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	public String getDisplayType() {
		return displayType;
	}
	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}
	
}

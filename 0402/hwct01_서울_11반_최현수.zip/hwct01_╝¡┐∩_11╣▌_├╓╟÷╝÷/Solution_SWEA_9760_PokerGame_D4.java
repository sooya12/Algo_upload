import java.util.Arrays;
import java.util.Scanner;

public class Solution_SWEA_9760_PokerGame_D4 {
	
	static char[] srr; // 입력받은 5개의 카드의 슈트
	static int[] vrr; // 입력받은 5개의 카드의 값
	
	static String result;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int t = sc.nextInt(); // 테스트케이스 수
		
		for (int tc = 1; tc <= t; tc++) {
			srr = new char[5];
			vrr = new int[5];
			
			result = "High card";
			
			for (int i = 0; i < srr.length; i++) {
				String s = sc.next();
				
				srr[i] = s.charAt(0);
				if(s.charAt(1) == 'A') vrr[i] = 1;
				else if(s.charAt(1) == 'T') vrr[i] = 10;
				else if(s.charAt(1) == 'J') vrr[i] = 11;
				else if(s.charAt(1) == 'Q') vrr[i] = 12;
				else if(s.charAt(1) == 'K') vrr[i] = 13;
				else vrr[i] = s.charAt(1) - '0';
			}
			
			if(checkSuit() && checkStraight()) result = "Straight Flush";
			else {
				checkCount();
				if(checkStraight() && 
						(!result.equals("Four of a Kind") || !result.equals("Full House") || !result.equals("Flush"))) result = "Straight";
				else if(checkSuit() && !result.equals("Four of a Kind")) result = "Flush";
			}
			
			System.out.println("#" + tc + " " + result);
		}
	} // end of main
	
	// 카드 슈트가 모두 동일한지 확인
	private static boolean checkSuit() {
		char s = srr[0];
		
		for (int i = 1; i < srr.length; i++) {
			if(srr[i] != s) return false;
		}
		
		return true;
	}
	
	// 카드 값이 연속적인지 확인
	private static boolean checkStraight() {
		int[] tmp = vrr.clone();
		
		Arrays.sort(tmp);
		
		int s = tmp[0];
	
		for (int i = 1; i < tmp.length; i++) {
			if(s == 1 && tmp[i] == 10) { // 로얄 플러쉬인 경우 (A, T, J, Q, K)
				s = 10;
			} else {
				if(tmp[i] != s+1) return false;
				
				s += 1;
			}
		}
		
		return true;
	}
	
	private static void checkCount() {
		int cnt = 1;
		
		int[] tmp = vrr.clone();
		Arrays.sort(tmp);
		
		int s = tmp[0];
		
		for (int i = 1; i < tmp.length; i++) {
			if(s == tmp[i]) cnt++;
			
			if(s != tmp[i] || i == tmp.length - 1) {
				
				if(cnt == 1) {
					s = tmp[i];
					cnt = 1;
				}
				
				else if(cnt == 2 && result.equals("High card")) {
					result = "One pair";
					s = tmp[i];
					cnt = 1;
				} else if(cnt == 2 && result.equals("One pair")) {
					result = "Two pair";
					return;
				} else if(cnt == 3 && result.equals("High card")) {
					result = "Three of a kind";
					s = tmp[i];
					cnt = 1;
				} else if(cnt == 3 && result.equals("One pair")) {
					result = "Full House";
					return;
				} else if(cnt == 2 && result.equals("Three of a kind")) {
					result = "Full House";
					return;
				} else if(cnt == 4 && result.equals("High card")) {
					result = "Four of a Kind";
					return;
				}
			}
			
		}
	}
	
}

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution_SWEA_6719_성수의프로그래밍강좌시청_D4 {
	
	static int n;
	static int k;
	static int[] mrr;
	static double max;
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;

		int t = Integer.parseInt(br.readLine()); // 테스트케이스 수

		for (int tc = 1; tc <= t; tc++) {
			st = new StringTokenizer(br.readLine(), " ");
			
			n = Integer.parseInt(st.nextToken());
			k = Integer.parseInt(st.nextToken());
			
			mrr = new int[n];
			
			st = new StringTokenizer(br.readLine(), " ");
			
			for (int i = 0; i < n; i++) {
				mrr[i] = Integer.parseInt(st.nextToken());
			}
			
			Arrays.sort(mrr);
			
			int[] tmp = new int[k];
			
			for (int i = 0; i < tmp.length; i++) {
				tmp[tmp.length - 1 - i] = mrr[mrr.length - 1 - i];
			}
			
			max = 0;
			
			for (int i = 0; i < k; i++) {
				max += (double)tmp[i] / Math.pow(2, k-i);
			}
			
			System.out.printf("#" + tc + " %.6f\n", max);
			
		}
	} // end of main
	
}

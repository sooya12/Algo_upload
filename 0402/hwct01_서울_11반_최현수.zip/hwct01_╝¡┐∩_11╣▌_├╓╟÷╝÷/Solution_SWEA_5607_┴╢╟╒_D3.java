import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution_SWEA_5607_조합_D3 {
	
	static final int MOD = 1234567891;
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		
		int t = Integer.parseInt(br.readLine()); // 테스트케이스 수
		
		for (int tc = 1; tc <= t; tc++) {
			st = new StringTokenizer(br.readLine(), " ");
			
			int n = Integer.parseInt(st.nextToken());
			int r = Integer.parseInt(st.nextToken());
			
			long factorial[] = new long[n+1];
			
			factorial[0] = 1;
			
			for (int i = 1; i < n+1; i++) {
				factorial[i] = (factorial[i-1] * i) % MOD;
			}
			
			long val = (factorial[r] * factorial[n-r]) % MOD;
			long reVal = cal(val, MOD - 2);
			
			System.out.println("#" + tc + " " + (factorial[n] * reVal) % MOD);
		}
	}
	
	private static long cal(long n, int x) {
		if(x == 0) return 1;
		
		long tmp = cal(n, x/2);
		
		long result = (tmp * tmp) % MOD;
		
		if(x % 2 == 0) return result;
		else return (result * n) % MOD;
	}
}